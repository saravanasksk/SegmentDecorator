﻿using Syncfusion.UI.Xaml.Diagram;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SegmentEx1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

             ObservableCollection<ConnectorViewModel> lines = new ObservableCollection<ConnectorViewModel>();

            ConnectorViewModel connector = new ConnectorViewModel()
            {
                SourceNodeID = "First",
                TargetNodeID = "Second",
                
                //SourcePoint = new Point(100, 200),
                //TargetPoint = new Point(300, 300),

                //Add the Straight Segment to Segments
                Segments = new ObservableCollection<IConnectorSegment>()
                {
                    new StraightSegment()
            }
            };

            ConnectorViewModel connector1 = new ConnectorViewModel()
            {
                SourceNodeID = "Third",
                TargetNodeID = "Fourth",
                //SourcePoint = new Point(250, 180),
                //TargetPoint = new Point(380, 380),

                //Add the Orthogonal Segment to Segments
                Segments = new ObservableCollection<IConnectorSegment>()
                {
                   new OrthogonalSegment()
                     {
                        Length = 50,
                        Direction = OrthogonalDirection.Bottom
                     }
            }
            };
            lines.Add(connector);
            lines.Add(connector1);
            diagram.Connectors = lines;
            
            var decorator1 = new SegmentDecorator() { Length = 0.5, Mode = SegmentDecoratorMode.Relative, Recursive = SegmentDecoratorAbsoluteMode.False };
            var decorator2 = new SegmentDecorator() { Length = 35, Mode = SegmentDecoratorMode.Absolute, Recursive = SegmentDecoratorAbsoluteMode.True };
            
            //var decorator3 = new SegmentDecorator() { Length = 0.3, RelativeMode = SegmentDecoratorRelativeMode.Segment };
            //var decorator4 = new SegmentDecorator() { Length = 0.7, RelativeMode = SegmentDecoratorRelativeMode.Connector };
            //var decorator5 = new SegmentDecorator() { Length = 75, Recursive = SegmentDecoratorAbsoluteMode.True, Mode = SegmentDecoratorMode.Absolute };
            //var decorator6 = new SegmentDecorator() { Length = 100, Recursive = SegmentDecoratorAbsoluteMode.False, Mode = SegmentDecoratorMode.Absolute };

            connector.SegmentDecorators  = new ObservableCollection<SegmentDecorator>() { decorator1 };
            connector1.SegmentDecorators = new ObservableCollection<SegmentDecorator>() { decorator2 };



            //decorator1.Length = Convert.ToDouble((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>);


            (diagram.Info as IGraphInfo).ItemSelectedEvent += MainWindow_ItemSelectedEvent;
    
        }

        private void MainWindow_ItemSelectedEvent(object sender, DiagramEventArgs args)
        {
            if(args.Item is IConnector)
            {
                SegmentDecorator decorator = ((args.Item as ConnectorViewModel).SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
                Length_Value.Text = decorator.Length.ToString();
                if(decorator.Recursive == SegmentDecoratorAbsoluteMode.True)
                {
                    trueBox.IsChecked = true;
                }
                else
                {
                    trueBox.IsChecked = false;
                }
                if(decorator.Mode == SegmentDecoratorMode.Absolute)
                {
                    comboBox.SelectedIndex = 0;
                }
                else
                {
                    comboBox.SelectedIndex = 1;
                }

            }
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    (diagram.Connectors as ObservableCollection<ConnectorViewModel>).Count();
        //    ConnectorViewModel res;
        //    res = (diagram.Connectors as ObservableCollection<ConnectorViewModel>)[0];
        //    //StraightSegment seg = (res.Segments as ObservableCollection<IConnectorSegment>)[0] as StraightSegment;
        //    //seg.Point = new Point(100, 100);
        //    //res.SourcePoint = new Point(res.SourcePoint.X + 1, res.SourcePoint.Y);
        //    SegmentDecorator dec;
        //    dec = (res.SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
        //    dec.Length = Convert.ToDouble(Length_Value.Text);
        //    //res.SourcePoint = new Point(res.SourcePoint.X + 0.0000001, res.SourcePoint.Y);

        //}



        private void trueBox_Checked(object sender, RoutedEventArgs e)
        {
            (diagram.Connectors as ObservableCollection<ConnectorViewModel>).Count();
            ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).Count();
            object res3;
            res3 = ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).ToList()[0];
            SegmentDecorator dec3;
            dec3 = ((res3 as ConnectorViewModel).SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
            dec3.Recursive = SegmentDecoratorAbsoluteMode.True;
           
            //res3.SourcePoint = new Point(res3.SourcePoint.X + 0.0000001, res3.SourcePoint.Y);
        }
        private void trueBox_Unchecked(object sender, RoutedEventArgs e)
        {
            (diagram.Connectors as ObservableCollection<ConnectorViewModel>).Count();
            ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).Count();
            object res4;  
            res4 = ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).ToList()[0];
            SegmentDecorator dec4;
            dec4 = ((res4 as ConnectorViewModel).SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
            dec4.Recursive = SegmentDecoratorAbsoluteMode.False;
          //res4.SourcePoint = new Point(res4.SourcePoint.X + 0.0000001, res4.SourcePoint.Y);
        }


        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if ("Absolute" == ((ComboBoxItem)comboBox.SelectedItem).Content.ToString())
            {
                (diagram.Connectors as ObservableCollection<ConnectorViewModel>).Count();
                ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).Count();
                object res5;     
                res5 = ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).ToList()[0];
                SegmentDecorator dec5;
                dec5 = ((res5 as ConnectorViewModel).SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
                dec5.Mode = SegmentDecoratorMode.Absolute;
            }
            else
            {
                (diagram.Connectors as ObservableCollection<ConnectorViewModel>).Count();
                ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).Count();
                object res6;                    
                res6 = ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).ToList()[0];
                SegmentDecorator dec6;
                dec6 = ((res6 as ConnectorViewModel).SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
                dec6.Mode = SegmentDecoratorMode.Relative;
            }
        }

        private void Length_Value_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (diagram == null) return; 
            (diagram.Connectors as ObservableCollection<ConnectorViewModel>).Count();
            ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).Count();
            object res;
           //res = (diagram.Connectors as ObservableCollection<ConnectorViewModel>)[0];
            res = ((diagram.SelectedItems as SelectorViewModel).Connectors as IEnumerable<object>).ToList()[0];
            SegmentDecorator dec;
            dec = ((res as ConnectorViewModel).SegmentDecorators as ObservableCollection<SegmentDecorator>)[0];
          
            double len = 0.0;
            double.TryParse(Length_Value.Text, out len);
            dec.Length = len;

        }
    }
}